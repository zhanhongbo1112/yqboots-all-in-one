import { NgModule }                         from '@angular/core';
import { BrowserModule }                    from '@angular/platform-browser';
import { FormsModule }                      from '@angular/forms';
import { RouterModule }                     from '@angular/router';

import { AppComponent }                     from './app.component';
import { AppRoutingModule }                 from './app-routing.module';

import { MailSubscriptionComponent }        from './service/mail/mail-subscription.component';
import { MailSubscriptionFormComponent }    from './service/mail/mail-subscription-form.component';
import { MailSubscriptionService }          from './service/mail/mail-subscription.service';

@NgModule({
  imports:      [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  declarations: [
    AppComponent,
    MailSubscriptionComponent
  ],
  providers:    [ MailSubscriptionService ],
  bootstrap:    [ AppComponent ]
})

export class AppModule {
}