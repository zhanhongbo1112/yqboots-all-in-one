import { Component, Input } from '@angular/core';

import { MailSubscription } from './mail-subscription';

@Component({
  selector: 'mail-subscription-form',
})

export class MailSubscriptionFormComponent {
}