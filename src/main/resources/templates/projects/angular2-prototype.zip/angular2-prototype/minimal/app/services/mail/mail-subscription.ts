export class MailSubscription {
  id: number;
  mailAddress: string;
  type: number;
}