import { Component, OnInit }        from '@angular/core';

import { MailSubscription }         from './mail-subscription';

@Component({
    selector: 'mail-subscriptions',
    templateUrl: 'mail-subscription.component.html'
})

export class AppComponent implements OnInit {
    subscriptions: MailSubscription[],

    constructor(private mailSubscriptionService: MailSubscriptionService) { },

    getMailSubscriptions(): void {
       this.mailSubscriptionService.getMailSubscriptions().then(subscriptions => this.subscriptions = subscriptions);
    },

    ngOnInit(): void {
        this.getMailSubscriptions();
    }
}