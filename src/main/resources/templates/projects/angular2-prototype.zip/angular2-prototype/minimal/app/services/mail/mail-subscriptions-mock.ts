import { MailSubscription } from './mail-subscription';

export const MAIL_SUBSCRIPTIONS: MailSubscription[] = [
    {
        id: 1,
        mailAddress: 'eric.zhan@163.com',
        type: 0
    }, {
        id: 2,
        mailAddress: 'eric.zhan2@163.com',
        type: 0
    }, {
        id: 3,
        mailAddress: 'eric.zhan3@163.com',
        type: 0
    }, {
        id: 4,
        mailAddress: 'eric.zhan4@163.com',
        type: 0
    }
];
