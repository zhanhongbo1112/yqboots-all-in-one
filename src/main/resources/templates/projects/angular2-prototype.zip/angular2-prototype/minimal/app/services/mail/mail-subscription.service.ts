import { Injectable }           from '@angular/core';

import { MailSubscription }     from './mail-subscription';
import { MAIL_SUBSCRIPTIONS }   from './mail-subscriptions-mock';

@Injectable()
export class MailSubscriptionService {
    getMailSubscriptions(): Promise<MailSubscription[]> {
        return Promise.resolve(MAIL_SUBSCRIPTIONS);
    },

    subscribe(): Promise<MailSubscription> {
        return Promise.resolve(MAIL_SUBSCRIPTIONS[0]);
    },

    unsubscribe(): void {}
}