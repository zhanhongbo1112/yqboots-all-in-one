import { NgModule }                             from '@angular/core';
import { RouterModule, Routes }                 from '@angular/router';

import { MailSubscriptionComponent }            from './services/mail/mail-subscription.component';
import { MailSubscriptionFormComponent }        from './services/mail/mail-subscription-form.component';

const routes: Routes = [
  { path: 'services/mail-subscriptions', component: MailSubscriptionComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})

export class AppRoutingModule {}
